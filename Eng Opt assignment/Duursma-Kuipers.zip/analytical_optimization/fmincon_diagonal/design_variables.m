constants;
wa = @(x) x(1);
wb = @(x) x(2);
L = @(x) x(3);
F  = @(x) x(4);