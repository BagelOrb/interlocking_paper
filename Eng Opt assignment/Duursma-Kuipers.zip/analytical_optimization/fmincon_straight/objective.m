design_variables;
f = @(x) (wa + wb(x)) * (hf(x) + hc) / F(x);