constants;
f = @(wa, wb, L, F)  (wa + wb) *2* h / F;