wb = @(x) x(1);
va = @(x) x(2);
vb = @(x) x(3);
hf = @(x) x(4);
F  = @(x) x(5);